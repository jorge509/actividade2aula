package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText nome;
    private EditText seña;
    private Button btn;
    private TextView tv1;
    private TextView tv2;
private String dados;
    private Button btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


              tv1=(TextView)findViewById(R.id.tv1);
            nome = (EditText) findViewById(R.id.nome);
            seña = (EditText) findViewById(R.id.seña);
            btn = (Button) findViewById(R.id.btn);

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    if
                    (nome.getText().toString().equals("user") && seña.getText().toString().equals("123")) {
                        Intent intent = new Intent(getApplicationContext(), MainActivity2.class);
                        Bundle params=new Bundle();
                        intent.putExtras(params);
                        startActivity(intent);



                    } else {
                        Toast.makeText(getApplicationContext(), "dados incorrectos", Toast.LENGTH_LONG).show();
                    }
                    btn.setOnClickListener(this);
                    btn2.setOnClickListener(this);


                }
            });
        }




    @Override
    public void onClick(View view) {
if(view.getId()==R.id.btn) {
    nome.getText().toString();
    tv1.setText((CharSequence) nome);
}else if (view.getId()==R.id.btn2){
    Intent intent=new Intent(this,MainActivity2.class);
    Bundle params=new Bundle();
    params.putString("chave", String.valueOf(nome));
    startActivity(intent);
    intent.putExtras(params);
    }

}
    }




