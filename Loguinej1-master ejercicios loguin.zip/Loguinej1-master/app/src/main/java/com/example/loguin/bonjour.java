package com.example.loguin;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class bonjour extends AppCompatActivity {
private TextView t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bonjour);
    t=(TextView)  findViewById((R.id.btn2));
    Bundle args =getIntent().getExtras();
    String Nombre=args.getString("chavenome");
t.setText(Nombre+"seja bem vindo");
    }
}