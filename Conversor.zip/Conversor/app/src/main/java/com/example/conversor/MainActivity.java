package com.example.conversor;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
EditText real,pesos,dolares;
Button btn1,btn2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        real=(EditText)findViewById(R.id.valor1);
        pesos=(EditText)findViewById(R.id.valor2);
        dolares=(EditText)findViewById(R.id.valor3);
       btn1=(Button)findViewById(R.id.btn1);

        btn2=(Button)findViewById(R.id.btn2);

        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String reals=pesos.getText().toString();
                Double re=Double.parseDouble(reals);
                Double dol=re*45;
                String p=String.valueOf(dol);
                dolares.setText(p);
            }
        });

        btn1.setOnClickListener(new View.OnClickListener() {
           @Override
           public void onClick(View view) {
               String reals=real.getText().toString();
               Double re=Double.parseDouble(reals);
               Double pes=re*8.50;
               String peso=String.valueOf(pes);
               pesos.setText(peso);



           }
       });







    }
}