package com.example.ejercicio5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{
private Button btn1;
private Button btn2;
private Button  btn3;
private ProgressBar pb1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn1=(Button) findViewById(R.id.btn1);
        btn2=(Button) findViewById(R.id.btn2);
        btn3.setOnClickListener(this);

        btn1.setOnClickListener(this);
        btn2.setOnClickListener(this);
        btn3.setOnClickListener(this);

        pb1=(ProgressBar) findViewById(R.id.pb1);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.btn1){
            pb1.setVisibility(View.INVISIBLE);
        Intent intent = new Intent(getApplicationContext(), segunda_tela.class);
        startActivity(intent);
    }
        else if(view.getId()==R.id.btn2){
        Intent intent=new Intent(getApplicationContext(),terceira_teela.class);
    }
        else if(view.getId()==R.id.btn3){
            Intent intent=new Intent(getApplicationContext(),tela4.class);
        }
}
    }
